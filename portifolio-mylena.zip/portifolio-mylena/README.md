# Mylena Almeida

## Social Media & Estrategista de Conteúdo

### Quem sou eu?

Sou Mylena Almeida, Social Media e Estrategista de Conteúdo.

Uno estratégia, criatividade e posicionamento digital para transformar ideias em conteúdos que conectam marcas e pessoas.

## Minha trajetória

- Planejamento estratégico de conteúdo;
- Gestão de redes sociais;
- Criação de conteúdo e copywriting;
- Produção e edição de fotos e vídeos;
- Direção criativa e desenvolvimento de peças;
- Planejamento de pautas e calendários editoriais;
- Estratégia de marca e posicionamento digital;
- Utilização de ferramentas de Inteligência Artificial;
- Reuniões de alinhamento e relacionamento com clientes;
- Planejamento e participação em produções de conteúdo;
- Participação em treinamentos, reuniões internas e atividades de capacitação.

## Projetos e experiências

### Volpe Revestimentos

Planejamento estratégico de conteúdo para uma marca do segmento de revestimentos, com foco nas necessidades dos profissionais de arquitetura e nas soluções oferecidas pela empresa.

### Amom

Estratégia de conteúdo para o segmento de Tarô, com desenvolvimento de pautas, identidade visual e criação de peças para redes sociais.

### Pizzaria Maia

Criação de conteúdos voltados para vendas, divulgação de produtos e fortalecimento da presença digital.

### BED & Design

Desenvolvimento de conteúdos e ações estratégicas para a marca.

## Ferramentas e habilidades

### Estratégia e planejamento

- Planejamento estratégico de conteúdo para redes sociais;
- Planejamento de pautas e calendários editoriais;
- Estratégias de marca e posicionamento digital;
- Organização da comunicação de acordo com os objetivos de cada cliente.

### Conteúdo e criação

- Criação de conteúdo para diferentes formatos e plataformas;
- Copywriting;
- Produção e edição de vídeos e fotografias;
- Direção criativa;
- Desenvolvimento de peças visuais;
- Planejamento e participação em sessões de fotografia e filmagens.

### Relacionamento e processos

- Gestão de redes sociais;
- Reuniões de alinhamento com clientes;
- Compreensão de demandas e definição de direcionamentos;
- Acompanhamento de projetos;
- Treinamentos e atividades de capacitação com clientes;
- Participação em reuniões internas.

## Inteligência Artificial

A Inteligência Artificial faz parte do meu processo de criação, planejamento e desenvolvimento de conteúdos.

Utilizo ferramentas de IA para:

- Criar e editar imagens;
- Desenvolver conceitos visuais e referências criativas;
- Apoiar a produção de vídeos e conteúdos audiovisuais;
- Pesquisar referências e desenvolver ideias;
- Otimizar processos de criação e planejamento de conteúdo;
- Ampliar possibilidades criativas e tornar os fluxos de trabalho mais eficientes.

## Formação

### IT for Girls 2025

Certificado de conclusão com carga horária total de **9 horas**, distribuídas em mentorias sobre:

- Ciência de Dados;
- Computação em Nuvem;
- Cibersegurança;
- Gestão de Projetos;
- Desenvolvimento de Software;
- Carreira;
- Inteligência Artificial aplicada ao desenvolvimento profissional.

**Emitido em:** 20 de outubro de 2025  
**ID do certificado:** `9mt9ehyjku`

## Vamos transformar ideias em resultados?

Estratégia, criatividade e tecnologia se encontram para transformar ideias em projetos que conectam marcas e pessoas.

Estou pronta para novos desafios, conexões e oportunidades de criar algo extraordinário.

**Vamos construir o próximo projeto juntos?**
